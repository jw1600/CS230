package com.gamingroom;

import java.util.List;
import java.util.ArrayList;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */

//Team class inherit entity class
public class Team extends Entity {
	long id;
	String name;
	//player list of the team
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public Player addPlayer(String name) {
		Player player = null;
		//to find if there is same player name
		for (int i = 0; i < players.size() - 1; i++) {
			if (players.get(i).getName() == name) {
				player = players.get(i);
			}
		}
		//if not, can add a new player;
		if (player == null) {
			GameService service = GameService.getInstance();
			player = new Player(service.getNextPlayerId(), name);
			players.add(player);
		}
		return player;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
}
